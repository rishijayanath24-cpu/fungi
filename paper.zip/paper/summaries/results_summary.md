# DeFungi V2 � Experiment Results Summary

| Experiment | Accuracy | F1 Macro | AUC Macro | Latency (ms) | Params (M) |
|:-----------|:--------:|:--------:|:---------:|:------------:|:----------:|
| efficientnet_b3 | 84.26% | 88.04% | --% | 12.7 | 10.7 |
| fusion_accuracy_weighted | 89.36% | 91.63% | --% | 0.0 | 0.0 |
| fusion_confidence_guided | 89.25% | 91.35% | --% | 0.0 | 0.0 |
| fusion_equal_weight | 89.47% | 91.59% | --% | 0.0 | 0.0 |
| fusion_learnable | 84.92% | 88.59% | --% | 0.0 | 0.0 |
| resnet50 | 78.71% | 81.61% | --% | 5.8 | 23.5 |
| swin_tiny | 91.02% | 92.66% | --% | 11.8 | 27.5 |
| vit_b16_224 | 84.70% | 88.47% | --% | 8.5 | 85.8 |
| vit_b16_384 | 89.69% | 91.88% | --% | 101.5 | 86.1 |